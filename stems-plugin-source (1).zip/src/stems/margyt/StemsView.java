package stems.margyt;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

/**
 * Полноэкранный прозрачный слой со стемами.
 * Касание мимо стема пропускается дальше в приложение.
 */
final class StemsView extends View {

    interface Logger {
        void log(String s);
    }

    // типы стемов
    static final int EYE = 0, LIPS = 1, NOSE = 2, EAR = 3;
    // состояния
    static final int NORMAL = 0, CROSS = 1, SHATTER = 2;
    // действия меню
    static final int A_SMASH = 0, A_CROSS = 1, A_FEED = 2;

    static final float TWO_PI = (float) (Math.PI * 2.0);
    // сцена «цепи» (мс от начала): подъём, падение цепей, утягивание вниз, конец
    static final long CH_LIFT = 600L, CH_DROP = 1300L, CH_PULL = 2300L, CH_END = 2700L;
    static final long SHATTER_MS = 2400L;

    static final class Stem {
        int type;
        int color, light, dark;
        Shader shader;
        float[] jit = new float[18];
        float[] fa = new float[6];
        float x, y, vx, vy, ang, angVel, r;
        float squash, fat = 1f, mouth;
        float lookX, lookY;
        float aiT, aiDir, aiSpeed;
        float crossX, startX, startY, chainScale = 1f;
        int state;
        boolean held, onGround;
        long stateT, blinkAt, blinkUntil, eatUntil, nextEggAt, popAt = -100000L;
        int eggsQueue, eatenNow;
        String bubble;
        long bubbleUntil;
    }

    static final class Egg {
        float x, y, vx, vy, rot, vr;
        Stem target;
    }

    static final class Part {
        float x, y, vx, vy, rot, vr, size;
        int color, kind; // 0 осколок, 1 капля, 2 скорлупа, 3 желток
        long born, life;
    }

    static final class Pop {
        float x, y;
        String text;
        int color;
        long born;
    }

    private final SharedPreferences prefs;
    private final Logger logger;
    private final float dp;
    private final boolean ru;
    private final int slop;
    private final Random rnd = new Random();

    private final ArrayList<Stem> stems = new ArrayList<Stem>();
    private final ArrayList<Egg> eggs = new ArrayList<Egg>();
    private final ArrayList<Part> parts = new ArrayList<Part>();
    private final ArrayList<Pop> pops = new ArrayList<Pop>();

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path clip = new Path();
    private final RectF rect = new RectF();
    private final Shader beamShader;

    private final RectF[] btn = new RectF[3];
    private final int[] btnAct = new int[3];
    private final String[] btnLabel = new String[3];

    private float floorY, gravity;
    private boolean placed, running, drawFailed;
    private long lastFrame;
    private long eggsTotal;

    // касание
    private Stem downStem, menuStem;
    private float downX, downY, offX, offY, lastX, lastY, velX, velY;
    private long lastMoveT, menuUntil;
    private boolean moved;
    private int pressedBtn = -1;
    private float gazeX, gazeY;
    private long gazeUntil;

    private final Runnable stepper = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            step();
            postOnAnimation(this);
        }
    };

    StemsView(Context context, SharedPreferences prefs, Logger logger) {
        super(context);
        this.prefs = prefs;
        this.logger = logger;
        this.dp = context.getResources().getDisplayMetrics().density;
        this.ru = "ru".equals(Locale.getDefault().getLanguage());
        this.slop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.gravity = 1500f * dp;
        this.beamShader = new LinearGradient(0f, 0f, 0f, -1f, 0x99BDEBFF, 0x00BDEBFF, Shader.TileMode.CLAMP);
        setWillNotDraw(false);

        for (int i = 0; i < 3; i++) btn[i] = new RectF();
        text.setTextAlign(Paint.Align.CENTER);
        line.setStyle(Paint.Style.STROKE);

        eggsTotal = prefs.getLong("eggs_total", 0L);
        stems.add(makeStem(EYE));
        stems.add(makeStem(LIPS));
        stems.add(makeStem(NOSE));
        stems.add(makeStem(EAR));
    }

    void destroy() {
        running = false;
        removeCallbacks(stepper);
    }

    // ------------------------------------------------------------ создание

    private Stem makeStem(int type) {
        Stem s = new Stem();
        s.type = type;
        s.r = 34f * dp;
        switch (type) {
            case EYE:
                s.color = 0xFFCB4630; s.light = 0xFFF58E64; s.dark = 0xFF7F2217; break;
            case LIPS:
                s.color = 0xFF4059D6; s.light = 0xFF8196FF; s.dark = 0xFF1F2C84; break;
            case NOSE:
                s.color = 0xFF3DB863; s.light = 0xFF8EF0A8; s.dark = 0xFF1A6A35; break;
            default:
                s.color = 0xFFD9792F; s.light = 0xFFFFB57B; s.dark = 0xFF8A3B16; break;
        }
        s.shader = new RadialGradient(-0.32f * s.r, -0.38f * s.r, 1.55f * s.r,
                new int[]{s.light, s.color, s.dark}, new float[]{0f, 0.5f, 1f},
                Shader.TileMode.CLAMP);
        for (int i = 0; i < s.jit.length; i++) s.jit[i] = rnd.nextFloat() * 2f - 1f;
        for (int i = 0; i < s.fa.length; i++) s.fa[i] = rnd.nextFloat() * TWO_PI;
        s.aiT = 0.3f + rnd.nextFloat() * 2f;
        s.aiDir = rnd.nextBoolean() ? 1f : -1f;
        s.aiSpeed = (70f + rnd.nextInt(80)) * dp;
        s.blinkAt = SystemClock.uptimeMillis() + 800 + rnd.nextInt(3000);
        return s;
    }

    private void updateFloor() {
        float h = getHeight();
        float r = 34f * dp;
        floorY = h - 96f * dp - r;
        if (floorY < 3f * r) floorY = h * 0.7f;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        updateFloor();
        if (!placed) {
            placed = true;
            int n = stems.size();
            for (int i = 0; i < n; i++) {
                Stem s = stems.get(i);
                s.x = (i + 0.5f) * w / n;
                s.y = floorY;
            }
            if (!prefs.getBoolean("hint_shown", false)) {
                prefs.edit().putBoolean("hint_shown", true).apply();
                say(stems.get(1), ru ? "Тап — меню, тащи — кидай!" : "Tap: menu. Drag: throw!", 5000);
            }
        } else {
            for (int i = 0; i < stems.size(); i++) {
                Stem s = stems.get(i);
                s.x = clamp(s.x, s.r, w - s.r);
                if (s.y > floorY) s.y = floorY;
            }
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        lastFrame = SystemClock.uptimeMillis();
        removeCallbacks(stepper);
        postOnAnimation(stepper);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        removeCallbacks(stepper);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------ фразы

    private static final String[] RU_TAP = {"Привет!", "Щекотно!", "Эй!", "Чего?", "Я стем!"};
    private static final String[] EN_TAP = {"Hi!", "Tickles!", "Hey!", "What?", "I'm a stem!"};
    private static final String[] RU_THROW = {"Уииии!", "Аааа!", "Лечууу!", "Полёт!"};
    private static final String[] EN_THROW = {"Wheee!", "Aaaah!", "Flying!", "Weeee!"};
    private static final String[] RU_CROSS = {"За что?!", "Я невиновен!", "Аааа!", "Нет-нет-нет!"};
    private static final String[] EN_CROSS = {"Why me?!", "I'm innocent!", "Aaaah!", "No no no!"};
    private static final String[] RU_FED = {"Ням!", "Вкусно!", "Ещё яйцо!", "Мммм!", "Ам!"};
    private static final String[] EN_FED = {"Yum!", "Tasty!", "More eggs!", "Mmmm!", "Nom!"};
    private static final String[] RU_BACK = {"Я вернулся!", "Я снова тут!", "Собрался!"};
    private static final String[] EN_BACK = {"I'm back!", "Reassembled!", "Miss me?"};
    private static final String[] RU_FREE = {"Свобода!", "Уф, спасибо!", "Наконец-то!"};
    private static final String[] EN_FREE = {"Free!", "Phew, thanks!", "Finally!"};
    private static final String[] RU_BUMP = {"Ой!", "Бум!", "Осторожнее!"};
    private static final String[] EN_BUMP = {"Oof!", "Bonk!", "Watch it!"};
    private static final String[] RU_IDLE = {"Катимся~", "Ля-ля-ля", "Кто тут?", "Я катаюсь!"};
    private static final String[] EN_IDLE = {"Rolling~", "La la la", "Who's there?", "Rolling around!"};

    private String pick(String[] a, String[] b) {
        String[] x = ru ? a : b;
        return x[rnd.nextInt(x.length)];
    }

    private void say(Stem s, String t, long ms) {
        s.bubble = t;
        s.bubbleUntil = SystemClock.uptimeMillis() + ms;
    }

    private void pop(float x, float y, String t, int color) {
        Pop p = new Pop();
        p.x = x;
        p.y = y;
        p.text = t;
        p.color = color;
        p.born = SystemClock.uptimeMillis();
        pops.add(p);
    }

    // ------------------------------------------------------------ цикл

    private void step() {
        try {
            long now = SystemClock.uptimeMillis();
            float dt = (now - lastFrame) / 1000f;
            lastFrame = now;
            if (dt > 0.05f) dt = 0.05f;
            if (dt <= 0f) dt = 0.001f;
            if (getWidth() <= 0 || getHeight() <= 0) return;
            updateFloor();

            for (int i = 0; i < stems.size(); i++) updateStem(stems.get(i), now, dt);
            collide();

            for (int i = eggs.size() - 1; i >= 0; i--) {
                if (updateEgg(eggs.get(i), now, dt)) eggs.remove(i);
            }
            for (int i = parts.size() - 1; i >= 0; i--) {
                if (updatePart(parts.get(i), now, dt)) parts.remove(i);
            }
            for (int i = pops.size() - 1; i >= 0; i--) {
                if (now - pops.get(i).born > 900) pops.remove(i);
            }
            if (menuStem != null && now > menuUntil) closeMenu();
            invalidate();
        } catch (Throwable t) {
            safeLog("stems: step failed: " + t);
        }
    }

    private void updateStem(Stem s, long now, float dt) {
        float w = getWidth();
        if (s.squash > 0f) {
            s.squash -= dt * 3.2f;
            if (s.squash < 0f) s.squash = 0f;
        }
        if (s.fat > 1f) {
            s.fat -= dt * 0.012f;
            if (s.fat < 1f) s.fat = 1f;
        }
        if (now < s.eatUntil) {
            s.mouth = 0.5f + 0.5f * (float) Math.sin(now * 0.028);
        } else {
            s.mouth += (0f - s.mouth) * Math.min(1f, dt * 10f);
        }
        if (now >= s.blinkAt) {
            s.blinkUntil = now + 130;
            s.blinkAt = now + 1800 + rnd.nextInt(3200);
        }
        if (s.state == SHATTER) {
            if (now - s.stateT > SHATTER_MS) respawn(s, now);
            return;
        }
        if (s.eggsQueue > 0 && now >= s.nextEggAt) {
            dropEgg(s);
            s.eggsQueue--;
            s.nextEggAt = now + 520;
        }

        // взгляд
        float tx, ty;
        if (s.state == CROSS) {
            tx = 0f;
            ty = 1f;
        } else if (now < gazeUntil) {
            float dx = gazeX - s.x, dy = gazeY - s.y;
            float len = (float) Math.sqrt(dx * dx + dy * dy) + 1f;
            float k = Math.min(1f, len / (3f * s.r));
            tx = dx / len * k;
            ty = dy / len * k;
        } else {
            tx = clamp(s.vx / (350f * dp), -1f, 1f);
            ty = clamp(s.vy / (700f * dp), -1f, 1f);
        }
        float lk = Math.min(1f, 10f * dt);
        s.lookX += (tx - s.lookX) * lk;
        s.lookY += (ty - s.lookY) * lk;

        if (s.state == CROSS) {
            updateChain(s, now);
            return;
        }
        if (s.held) {
            s.angVel *= (1f - 2f * dt);
            s.ang += s.angVel * dt;
            return;
        }

        // физика
        s.vy += gravity * dt;
        s.x += s.vx * dt;
        s.y += s.vy * dt;
        s.onGround = false;
        if (s.y >= floorY) {
            float impact = s.vy;
            s.y = floorY;
            if (impact > 260f * dp) {
                s.vy = -impact * 0.45f;
                s.squash = Math.min(1f, impact / (1600f * dp));
                if (impact > 1500f * dp && rnd.nextInt(3) == 0) say(s, pick(RU_BUMP, EN_BUMP), 1200);
            } else {
                s.vy = 0f;
                s.onGround = true;
            }
        }
        if (s.x < s.r) {
            s.x = s.r;
            s.vx = -s.vx * 0.7f;
            s.aiDir = 1f;
        } else if (s.x > w - s.r) {
            s.x = w - s.r;
            s.vx = -s.vx * 0.7f;
            s.aiDir = -1f;
        }
        if (s.y < s.r) {
            s.y = s.r;
            if (s.vy < 0f) s.vy = -s.vy * 0.5f;
        }

        if (s.onGround) {
            s.aiT -= dt;
            if (s.aiT <= 0f) pickIdle(s);
            float want = s.aiDir * s.aiSpeed;
            float diff = want - s.vx;
            float acc = (Math.abs(s.vx) > s.aiSpeed * 1.3f ? 1200f : 500f) * dp * dt;
            if (diff > acc) diff = acc;
            else if (diff < -acc) diff = -acc;
            s.vx += diff;
            s.angVel = s.vx / s.r;
        } else {
            s.vx *= (1f - 0.1f * dt);
            s.angVel *= (1f - 0.2f * dt);
        }
        s.ang += s.angVel * dt;
    }

    private void pickIdle(Stem s) {
        s.aiT = 1.5f + rnd.nextFloat() * 3.5f;
        float p = rnd.nextFloat();
        s.aiDir = p < 0.18f ? 0f : (rnd.nextBoolean() ? 1f : -1f);
        s.aiSpeed = (70f + rnd.nextInt(90)) * dp;
        if (p > 0.9f) {
            s.vy = -(520f + rnd.nextInt(300)) * dp;
            s.onGround = false;
        }
        if (rnd.nextInt(9) == 0) say(s, pick(RU_IDLE, EN_IDLE), 1800);
    }

    private void collide() {
        int n = stems.size();
        for (int i = 0; i < n; i++) {
            Stem a = stems.get(i);
            if (a.state != NORMAL) continue;
            for (int j = i + 1; j < n; j++) {
                Stem b = stems.get(j);
                if (b.state != NORMAL) continue;
                if (a.held && b.held) continue;
                float dx = b.x - a.x, dy = b.y - a.y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                float min = (a.r + b.r) * 0.95f;
                if (dist >= min || dist < 0.001f) continue;
                float nx = dx / dist, ny = dy / dist;
                float overlap = min - dist;
                float wa = a.held ? 0f : (b.held ? 1f : 0.5f);
                float wb = b.held ? 0f : (a.held ? 1f : 0.5f);
                a.x -= nx * overlap * wa;
                a.y -= ny * overlap * wa;
                b.x += nx * overlap * wb;
                b.y += ny * overlap * wb;
                float rvx = b.vx - a.vx, rvy = b.vy - a.vy;
                float vn = rvx * nx + rvy * ny;
                if (vn < 0f) {
                    float imp = -(1f + 0.75f) * vn;
                    if (a.held) {
                        b.vx += nx * imp;
                        b.vy += ny * imp;
                    } else if (b.held) {
                        a.vx -= nx * imp;
                        a.vy -= ny * imp;
                    } else {
                        a.vx -= nx * imp * 0.5f;
                        a.vy -= ny * imp * 0.5f;
                        b.vx += nx * imp * 0.5f;
                        b.vy += ny * imp * 0.5f;
                    }
                    if (-vn > 350f * dp) {
                        a.squash = Math.max(a.squash, 0.5f);
                        b.squash = Math.max(b.squash, 0.5f);
                        if (-vn > 700f * dp && rnd.nextInt(3) == 0) {
                            say(rnd.nextBoolean() ? a : b, pick(RU_BUMP, EN_BUMP), 1100);
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ действия

    private void smash(Stem s) {
        long now = SystemClock.uptimeMillis();
        s.state = SHATTER;
        s.stateT = now;
        s.held = false;
        s.eggsQueue = 0;
        s.bubble = null;
        for (int i = 0; i < 16; i++) {
            Part p = newPart(s.x, s.y, 0, now, 1900 + rnd.nextInt(500));
            float a = rnd.nextFloat() * TWO_PI;
            float v = (200f + rnd.nextInt(700)) * dp;
            p.vx = (float) Math.cos(a) * v;
            p.vy = (float) Math.sin(a) * v - 350f * dp;
            p.size = s.r * (0.16f + rnd.nextFloat() * 0.2f);
            p.color = (i % 3 == 0) ? s.dark : ((i % 3 == 1) ? s.color : s.light);
        }
        for (int i = 0; i < 7; i++) {
            Part p = newPart(s.x, s.y, 1, now, 1500 + rnd.nextInt(500));
            float a = rnd.nextFloat() * TWO_PI;
            float v = (100f + rnd.nextInt(500)) * dp;
            p.vx = (float) Math.cos(a) * v;
            p.vy = (float) Math.sin(a) * v - 200f * dp;
            p.size = s.r * (0.07f + rnd.nextFloat() * 0.08f);
            p.color = s.dark;
        }
        pop(s.x, s.y - s.r, ru ? "БАМ!" : "SMASH!", 0xFFFF5A3C);
        performHapticFeedback(0);
    }

    private void respawn(Stem s, long now) {
        s.state = NORMAL;
        s.x = clamp(s.x + (rnd.nextFloat() - 0.5f) * 80f * dp, s.r, getWidth() - s.r);
        s.y = -s.r * 2f;
        s.vx = 0f;
        s.vy = 0f;
        s.squash = 0f;
        s.fat = 1f;
        s.popAt = now;
        say(s, pick(RU_BACK, EN_BACK), 2200);
    }

    private void crucify(Stem s) {
        long now = SystemClock.uptimeMillis();
        s.state = CROSS;
        s.stateT = now;
        s.held = false;
        s.eggsQueue = 0;
        s.startX = s.x;
        s.startY = s.y;
        s.crossX = clamp(s.x, 2.4f * s.r, getWidth() - 2.4f * s.r);
        s.chainScale = 1f;
        say(s, pick(RU_CROSS, EN_CROSS), 2400);
        performHapticFeedback(0);
    }

    /** Магический круг: стема поднимает вверх, цепи падают и утягивают его вниз. */
    private void updateChain(Stem s, long now) {
        float t = now - s.stateT;
        float r = s.r;
        float hoverY = floorY - 2.3f * r;
        float sinkY = floorY + 0.9f * r;
        s.vx = 0f;
        s.vy = 0f;
        s.angVel = 0f;
        float a = s.ang % TWO_PI;
        if (a > TWO_PI / 2f) a -= TWO_PI;
        if (a < -TWO_PI / 2f) a += TWO_PI;
        s.ang = a * 0.85f;
        if (t < CH_LIFT) {
            float k = easeOut(t / CH_LIFT);
            s.x = s.startX + (s.crossX - s.startX) * k;
            s.y = s.startY + (hoverY - s.startY) * k;
            s.chainScale = 1f;
        } else if (t < CH_DROP) {
            s.x = s.crossX + (float) Math.sin(t * 0.05) * 0.04f * r;
            s.y = hoverY + (float) Math.sin(t * 0.012) * 0.08f * r;
            s.chainScale = 1f;
        } else if (t < CH_PULL) {
            float q = (t - CH_DROP) / (float) (CH_PULL - CH_DROP);
            float e = q * q;
            s.x = s.crossX + (float) Math.sin(t * 0.06) * 0.05f * r * (1f - q);
            s.y = hoverY + (sinkY - hoverY) * e;
            s.chainScale = 1f - 0.9f * e;
        } else {
            s.y = sinkY;
            s.chainScale = 0.1f;
        }
        if (t >= CH_END) {
            s.state = SHATTER;
            s.stateT = now - (SHATTER_MS - 1200L);
            s.chainScale = 1f;
            s.bubble = null;
        }
    }

    private void feed(Stem s) {
        s.eggsQueue += 4;
        s.nextEggAt = SystemClock.uptimeMillis() + 150;
        s.eatenNow = 0;
    }

    private void dropEgg(Stem s) {
        Egg e = new Egg();
        e.x = clamp(s.x + (rnd.nextFloat() - 0.5f) * s.r * 2f, 10f * dp, getWidth() - 10f * dp);
        e.y = -16f * dp;
        e.vy = 150f * dp;
        e.vr = (rnd.nextFloat() - 0.5f) * 8f;
        e.target = s;
        eggs.add(e);
    }

    /** @return true, если яйцо нужно удалить */
    private boolean updateEgg(Egg e, long now, float dt) {
        e.vy += gravity * 0.6f * dt;
        e.y += e.vy * dt;
        e.rot += e.vr * dt;
        Stem t = e.target;
        if (t != null && t.state != SHATTER) {
            e.x += (t.x - e.x) * Math.min(1f, 3f * dt);
            float dx = t.x - e.x, dy = t.y - e.y;
            if (Math.sqrt(dx * dx + dy * dy) < t.r * 0.85f) {
                eaten(t, e, now);
                return true;
            }
        }
        if (e.y > floorY + 0.75f * 34f * dp) {
            for (int i = 0; i < 5; i++) {
                Part p = newPart(e.x, e.y, 2, now, 900);
                p.vx = (rnd.nextFloat() - 0.5f) * 300f * dp;
                p.vy = -(100f + rnd.nextInt(300)) * dp;
                p.size = (3f + rnd.nextInt(3)) * dp;
                p.color = 0xFFF6EDD9;
            }
            Part y = newPart(e.x, e.y, 3, now, 1400);
            y.size = 7f * dp;
            y.color = 0xFFFFC21A;
            return true;
        }
        return false;
    }

    private void eaten(Stem s, Egg e, long now) {
        s.eatUntil = now + 450;
        s.squash = Math.max(s.squash, 0.55f);
        s.fat = Math.min(1.3f, s.fat + 0.04f);
        s.eatenNow++;
        eggsTotal++;
        prefs.edit().putLong("eggs_total", eggsTotal).apply();
        for (int i = 0; i < 6; i++) {
            Part p = newPart(s.x, s.y - s.r * 0.3f, 2, now, 700);
            float a = rnd.nextFloat() * TWO_PI;
            float v = (100f + rnd.nextInt(250)) * dp;
            p.vx = (float) Math.cos(a) * v;
            p.vy = (float) Math.sin(a) * v - 150f * dp;
            p.size = (2f + rnd.nextInt(3)) * dp;
            p.color = 0xFFF6EDD9;
        }
        pop(s.x + s.r * 0.6f, s.y - s.r, "+1", 0xFFFFD34D);
        if (eggsTotal % 10 == 0) {
            say(s, (ru ? "Всего яиц: " : "Eggs eaten: ") + eggsTotal, 2500);
        } else if (s.eatenNow >= 4 && s.eggsQueue == 0) {
            say(s, ru ? "Ик! Хватит!" : "Burp! Enough!", 2200);
        } else {
            say(s, pick(RU_FED, EN_FED), 1300);
        }
    }

    private Part newPart(float x, float y, int kind, long now, long life) {
        Part p = new Part();
        p.x = x;
        p.y = y;
        p.kind = kind;
        p.born = now;
        p.life = life;
        p.rot = rnd.nextFloat() * TWO_PI;
        p.vr = (rnd.nextFloat() - 0.5f) * 14f;
        parts.add(p);
        return p;
    }

    /** @return true, если частицу нужно удалить */
    private boolean updatePart(Part p, long now, float dt) {
        if (now - p.born > p.life) return true;
        float groundY = floorY + 34f * dp * 0.9f;
        p.vy += gravity * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.rot += p.vr * dt;
        if (p.y > groundY) {
            p.y = groundY;
            p.vy = p.vy > 300f * dp ? -p.vy * 0.35f : 0f;
            p.vx *= 0.8f;
            p.vr *= 0.6f;
        }
        if (p.x < 0f || p.x > getWidth()) p.vx = -p.vx;
        return false;
    }

    // ------------------------------------------------------------ меню

    private void openMenu(Stem s) {
        menuStem = s;
        menuUntil = SystemClock.uptimeMillis() + 6000;
        pressedBtn = -1;
        btnAct[0] = A_CROSS;
        btnLabel[0] = ru ? "Распять" : "Crucify";
        btnAct[1] = A_SMASH;
        btnLabel[1] = ru ? "Разбить" : "Smash";
        btnAct[2] = A_FEED;
        btnLabel[2] = ru ? "Кормить яйцами" : "Feed eggs";

        float bw = 104f * dp, bh = 38f * dp, gap = 6f * dp;
        float total = 3f * bw + 2f * gap;
        float left = clamp(s.x - total / 2f, 6f * dp, getWidth() - total - 6f * dp);
        float top = s.y - s.r * 1.3f - bh - 10f * dp;
        if (top < 30f * dp) top = 30f * dp;
        for (int i = 0; i < 3; i++) {
            btn[i].set(left + i * (bw + gap), top, left + i * (bw + gap) + bw, top + bh);
        }
    }

    private void closeMenu() {
        menuStem = null;
        pressedBtn = -1;
    }

    private int hitButton(float x, float y) {
        if (menuStem == null) return -1;
        for (int i = 0; i < 3; i++) {
            if (btn[i].contains(x, y)) return i;
        }
        return -1;
    }

    private void onButton(int i) {
        Stem s = menuStem;
        if (s == null) return;
        int act = btnAct[i];
        closeMenu();
        switch (act) {
            case A_SMASH: smash(s); break;
            case A_CROSS: crucify(s); break;
            case A_FEED: feed(s); break;
            default: break;
        }
    }

    // ------------------------------------------------------------ касания

    private Stem hitStem(float x, float y) {
        for (int i = stems.size() - 1; i >= 0; i--) {
            Stem s = stems.get(i);
            if (s.state != NORMAL) continue;
            float dx = x - s.x, dy = y - s.y;
            float rr = s.r * 1.15f;
            if (dx * dx + dy * dy <= rr * rr) return s;
        }
        return null;
    }

    private void lockParent(boolean lock) {
        ViewParent p = getParent();
        if (p != null) p.requestDisallowInterceptTouchEvent(lock);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        try {
            return touch2(e);
        } catch (Throwable t) {
            safeLog("stems: touch failed: " + t);
            return false;
        }
    }

    private boolean touch2(MotionEvent e) {
        int a = e.getActionMasked();
        float x = e.getX(), y = e.getY();
        long now = SystemClock.uptimeMillis();
        gazeX = x;
        gazeY = y;
        gazeUntil = now + 2500;

        switch (a) {
            case MotionEvent.ACTION_DOWN: {
                if (menuStem != null) {
                    int b = hitButton(x, y);
                    if (b >= 0) {
                        pressedBtn = b;
                        return true;
                    }
                    closeMenu();
                }
                Stem s = hitStem(x, y);
                if (s == null) return false;
                // выбранный стем рисуется поверх остальных
                stems.remove(s);
                stems.add(s);
                downStem = s;
                downX = x;
                downY = y;
                offX = s.x - x;
                offY = s.y - y;
                lastX = x;
                lastY = y;
                lastMoveT = now;
                velX = 0f;
                velY = 0f;
                moved = false;
                lockParent(true);
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (pressedBtn >= 0) return true;
                Stem s = downStem;
                if (s == null) return false;
                if (!moved) {
                    float dx = x - downX, dy = y - downY;
                    if (Math.sqrt(dx * dx + dy * dy) > slop * 1.5f) {
                        moved = true;
                        closeMenu();
                        s.held = true;
                        s.eggsQueue = 0;
                        say(s, ru ? "Куда несёшь?!" : "Where to?!", 1500);
                    }
                }
                if (moved) {
                    s.x = clamp(x + offX, s.r, getWidth() - s.r);
                    s.y = clamp(y + offY, s.r, floorY);
                    float dt = (now - lastMoveT) / 1000f;
                    if (dt > 0.001f) {
                        float ivx = (x - lastX) / dt, ivy = (y - lastY) / dt;
                        velX = velX * 0.6f + ivx * 0.4f;
                        velY = velY * 0.6f + ivy * 0.4f;
                        lastX = x;
                        lastY = y;
                        lastMoveT = now;
                    }
                    s.vx = 0f;
                    s.vy = 0f;
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (pressedBtn >= 0) {
                    int b = pressedBtn;
                    pressedBtn = -1;
                    if (a == MotionEvent.ACTION_UP && hitButton(x, y) == b) onButton(b);
                    return true;
                }
                Stem s = downStem;
                downStem = null;
                lockParent(false);
                if (s == null) return false;
                if (moved) {
                    s.held = false;
                    if (now - lastMoveT > 90) {
                        velX = 0f;
                        velY = 0f;
                    }
                    float max = 3800f * dp;
                    s.vx = clamp(velX, -max, max);
                    s.vy = clamp(velY, -max, max);
                    s.angVel = s.vx / s.r + (rnd.nextFloat() - 0.5f) * 4f;
                    s.onGround = false;
                    float sp = (float) Math.sqrt(s.vx * s.vx + s.vy * s.vy);
                    if (sp > 900f * dp) say(s, pick(RU_THROW, EN_THROW), 1600);
                } else if (a == MotionEvent.ACTION_UP) {
                    s.squash = 0.5f;
                    if (rnd.nextInt(2) == 0) say(s, pick(RU_TAP, EN_TAP), 1500);
                    openMenu(s);
                }
                return true;
            }
            default:
                return downStem != null || pressedBtn >= 0;
        }
    }

    // ------------------------------------------------------------ рисование

    @Override
    protected void onDraw(Canvas c) {
        try {
            draw2(c);
        } catch (Throwable t) {
            if (!drawFailed) {
                drawFailed = true;
                safeLog("stems: draw failed: " + t);
            }
        }
    }

    private void draw2(Canvas c) {
        long now = SystemClock.uptimeMillis();
        int n = stems.size();
        for (int i = 0; i < n; i++) drawShadow(c, stems.get(i));
        for (int i = 0; i < n; i++) {
            Stem s = stems.get(i);
            if (s.state == CROSS) drawCircle(c, s, now);
        }
        for (int i = 0; i < n; i++) {
            Stem s = stems.get(i);
            if (s.state != SHATTER) drawStem(c, s, now);
        }
        for (int i = 0; i < n; i++) {
            Stem s = stems.get(i);
            if (s.state == CROSS) drawChains(c, s, now);
        }
        for (int i = 0; i < eggs.size(); i++) drawEgg(c, eggs.get(i));
        for (int i = 0; i < parts.size(); i++) drawPart(c, parts.get(i), now);
        for (int i = 0; i < n; i++) {
            Stem s = stems.get(i);
            if (s.bubble != null && now < s.bubbleUntil && s != menuStem && s.state != SHATTER) {
                drawBubble(c, s);
            }
        }
        if (menuStem != null) drawMenu(c);
        for (int i = 0; i < pops.size(); i++) drawPop(c, pops.get(i), now);
    }

    private void drawShadow(Canvas c, Stem s) {
        if (s.state == SHATTER || s.state == CROSS) return;
        float ground = floorY + s.r;
        float h = Math.max(0f, ground - (s.y + s.r));
        float k = 1f - Math.min(0.6f, h / (320f * dp));
        fill.setShader(null);
        fill.setColor(((int) (70 * k) << 24));
        rect.set(s.x - s.r * 0.9f * k * s.fat, ground - s.r * 0.12f,
                s.x + s.r * 0.9f * k * s.fat, ground + s.r * 0.2f);
        c.drawOval(rect, fill);
    }

    private float popScale(Stem s, long now) {
        long age = now - s.popAt;
        if (age >= 450 || age < 0) return 1f;
        float t = age / 450f;
        float c1 = 1.70158f, c3 = c1 + 1f;
        float u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    private void drawStem(Canvas c, Stem s, long now) {
        float r = s.r;
        float pop = popScale(s, now) * s.chainScale;
        float sq = s.squash;
        float sx = (1f + 0.28f * sq) * s.fat * pop;
        float sy = (1f - 0.28f * sq) * s.fat * pop;

        c.save();
        c.translate(s.x, s.y + r * (1f - sy));
        c.scale(sx, sy);

        // силуэт: многоугольник, который вращается вместе с катящимся шаром
        int n = s.jit.length;
        path.reset();
        for (int i = 0; i < n; i++) {
            float a = s.ang + i * TWO_PI / n;
            float rr = r * (0.97f + 0.03f * s.jit[i]);
            float px = (float) Math.cos(a) * rr, py = (float) Math.sin(a) * rr;
            if (i == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        path.close();

        // шипы-бугорки
        for (int k = 0; k < 7; k++) {
            float a = s.ang + 0.4f + k * TWO_PI / 7f;
            float cx = (float) Math.cos(a) * r * 0.95f, cy = (float) Math.sin(a) * r * 0.95f;
            float sr = r * (0.15f + 0.03f * s.jit[k]);
            fill.setShader(null);
            fill.setColor(s.dark);
            c.drawCircle(cx, cy, sr, fill);
            fill.setColor(s.color);
            c.drawCircle(cx - sr * 0.15f, cy - sr * 0.15f, sr * 0.75f, fill);
        }

        fill.setShader(s.shader);
        fill.setColor(0xFFFFFFFF);
        c.drawPath(path, fill);
        fill.setShader(null);

        // грани
        line.setStrokeWidth(1.2f * dp);
        line.setColor((s.dark & 0x00FFFFFF) | 0x66000000);
        c.drawPath(path, line);
        for (int k = 0; k < s.fa.length; k++) {
            float a = s.ang + s.fa[k];
            float a2 = a + 0.7f + 0.3f * s.jit[k];
            c.drawLine((float) Math.cos(a) * r * 0.3f, (float) Math.sin(a) * r * 0.3f,
                    (float) Math.cos(a2) * r * 0.92f, (float) Math.sin(a2) * r * 0.92f, line);
        }

        // лицо поворачивается медленнее тела
        float fAng = s.ang * 0.22f;
        c.save();
        c.rotate(fAng * 57.29578f);
        switch (s.type) {
            case EYE: drawEye(c, s, now, fAng); break;
            case LIPS: drawLips(c, s); break;
            case NOSE: drawNose(c, s, now); break;
            default: drawEar(c, s); break;
        }
        c.restore();

        if (s.state == CROSS) {
            fill.setColor(0xFF9FD8FF);
            c.drawCircle(r * 0.62f, -r * 0.5f, r * 0.07f, fill);
            path.reset();
            path.moveTo(r * 0.62f, -r * 0.7f);
            path.lineTo(r * 0.55f, -r * 0.55f);
            path.lineTo(r * 0.69f, -r * 0.55f);
            path.close();
            c.drawPath(path, fill);
        }
        c.restore();
    }

    private void drawEye(Canvas c, Stem s, long now, float fAng) {
        float r = s.r;
        fill.setColor(s.dark);
        rect.set(-0.52f * r, -0.46f * r, 0.52f * r, 0.46f * r);
        c.drawOval(rect, fill);

        float blink = (now < s.blinkUntil) ? 1f : 0f;
        float ey = 0.38f * r * (1f - 0.9f * blink);
        fill.setColor(0xFFF4F1EA);
        rect.set(-0.44f * r, -ey, 0.44f * r, ey);
        c.drawOval(rect, fill);

        if (blink < 0.5f) {
            float cf = (float) Math.cos(fAng), sf = (float) Math.sin(fAng);
            float ix = (s.lookX * cf + s.lookY * sf) * 0.17f * r;
            float iy = (-s.lookX * sf + s.lookY * cf) * 0.13f * r;
            fill.setColor(0xFF4A2210);
            c.drawCircle(ix, iy, 0.25f * r, fill);
            fill.setColor(0xFF8A4A22);
            c.drawCircle(ix, iy, 0.2f * r, fill);
            fill.setColor(0xFF0B0B0F);
            c.drawCircle(ix, iy, 0.115f * r, fill);
            fill.setColor(0xFFFFFFFF);
            c.drawCircle(ix - 0.07f * r, iy - 0.08f * r, 0.05f * r, fill);
        } else {
            line.setColor(s.dark);
            line.setStrokeWidth(2f * dp);
            c.drawLine(-0.44f * r, 0f, 0.44f * r, 0f, line);
        }
    }

    private void drawLips(Canvas c, Stem s) {
        float r = s.r;
        float w = 0.46f * r;
        float gap = (0.10f + 0.42f * s.mouth) * r;
        // губы
        fill.setColor(0xFF6C84FF);
        rect.set(-w * 1.28f, -gap / 2f - 0.17f * r, w * 1.28f, gap / 2f + 0.2f * r);
        c.drawOval(rect, fill);
        fill.setColor(0xFF4A62E6);
        rect.set(-w * 1.28f, 0f, w * 1.28f, gap / 2f + 0.2f * r);
        c.drawOval(rect, fill);
        // светлый блик
        fill.setColor(0x66FFFFFF);
        rect.set(-w * 0.95f, -gap / 2f - 0.14f * r, w * 0.1f, -gap / 2f - 0.05f * r);
        c.drawOval(rect, fill);
        // рот
        fill.setColor(0xFF2A1030);
        rect.set(-w, -gap / 2f, w, gap / 2f);
        c.drawOval(rect, fill);
        // зубы
        clip.reset();
        clip.addOval(rect, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        fill.setColor(0xFFF1F1F1);
        float th = Math.min(gap * 0.5f, 0.16f * r);
        float tw = 2f * w / 5f;
        for (int i = 0; i < 5; i++) {
            c.drawRect(-w + i * tw + 0.6f * dp, -gap / 2f, -w + (i + 1) * tw - 0.6f * dp, -gap / 2f + th, fill);
        }
        float bw = 2f * w / 4f;
        for (int i = 0; i < 4; i++) {
            c.drawRect(-w + i * bw + 0.6f * dp, gap / 2f - th * 0.8f, -w + (i + 1) * bw - 0.6f * dp, gap / 2f, fill);
        }
        c.restore();
    }

    private void drawNose(Canvas c, Stem s, long now) {
        float r = s.r;
        fill.setColor(s.dark);
        rect.set(-0.34f * r, -0.36f * r, 0.34f * r, 0.46f * r);
        c.drawOval(rect, fill);
        fill.setColor(0xFF63D681);
        rect.set(-0.31f * r, -0.4f * r, 0.31f * r, 0.4f * r);
        c.drawOval(rect, fill);
        fill.setColor(0x66FFFFFF);
        rect.set(-0.18f * r, -0.3f * r, 0.0f, -0.05f * r);
        c.drawOval(rect, fill);
        float pulse = 1f + 0.35f * s.mouth;
        fill.setColor(0xFF0E3A1C);
        rect.set(-0.2f * r, 0.17f * r, -0.04f * r, 0.17f * r + 0.1f * r * pulse);
        c.drawOval(rect, fill);
        rect.set(0.04f * r, 0.17f * r, 0.2f * r, 0.17f * r + 0.1f * r * pulse);
        c.drawOval(rect, fill);
    }

    private void drawEar(Canvas c, Stem s) {
        float r = s.r;
        fill.setColor(0xFF9E4318);
        rect.set(-0.36f * r, -0.52f * r, 0.36f * r, 0.52f * r);
        c.drawOval(rect, fill);
        fill.setColor(0xFFE98F56);
        rect.set(-0.31f * r, -0.47f * r, 0.31f * r, 0.47f * r);
        c.drawOval(rect, fill);
        fill.setColor(0xFFB4501F);
        rect.set(-0.2f * r, -0.34f * r, 0.2f * r, 0.34f * r);
        c.drawOval(rect, fill);
        fill.setColor(0xFF3A1210);
        rect.set(-0.08f * r, -0.05f * r, 0.08f * r, 0.2f * r);
        c.drawOval(rect, fill);
        fill.setColor(0xFFF2A56E);
        c.drawCircle(-0.1f * r, -0.1f * r, 0.07f * r, fill);
    }

    private static float easeOut(float t) {
        t = clamp(t, 0f, 1f);
        return 1f - (1f - t) * (1f - t);
    }

    private static int al(int color, float k) {
        int a = (int) (((color >>> 24) & 0xFF) * clamp(k, 0f, 1f));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    /** Светящийся магический круг на полу с лучом света. */
    private void drawCircle(Canvas c, Stem s, long now) {
        float t = now - s.stateT;
        float r = s.r;
        float grow = easeOut(t / 600f);
        float ca = grow;
        if (t > CH_PULL) ca = 1f - clamp((t - CH_PULL) / (float) (CH_END - CH_PULL), 0f, 1f);
        if (ca <= 0f) return;
        float big = 2.3f * r * (0.6f + 0.4f * grow);
        float cx = s.crossX, cy = floorY + 0.9f * r;
        float spin = t * 0.0007f;

        // столб света
        float beamA = ca * (t < CH_LIFT ? t / (float) CH_LIFT : 1f);
        fill.setShader(beamShader);
        fill.setColor(al(0xFFFFFFFF, beamA));
        c.save();
        c.translate(cx, cy);
        c.scale(big * 0.97f, 5.5f * r);
        rect.set(-1f, -1f, 1f, 0f);
        c.drawRect(rect, fill);
        c.restore();
        fill.setShader(null);

        // круг в перспективе
        c.save();
        c.translate(cx, cy);
        c.scale(1f, 0.36f);
        fill.setColor(al(0xFF7FD8FF, 0.25f * ca));
        c.drawCircle(0f, 0f, big, fill);

        line.setStrokeWidth(0.16f * big);
        line.setColor(al(0xFF8FE3FF, 0.30f * ca));
        c.drawCircle(0f, 0f, big, line);
        line.setStrokeWidth(0.05f * big);
        line.setColor(al(0xFFEFFBFF, 0.95f * ca));
        c.drawCircle(0f, 0f, big, line);

        float thin = Math.max(1f * dp, 0.014f * big);
        line.setStrokeWidth(thin);
        line.setColor(al(0xFFD5F4FF, 0.85f * ca));
        c.drawCircle(0f, 0f, 0.8f * big, line);
        c.drawCircle(0f, 0f, 0.7f * big, line);

        // руны и «фазы луны»
        fill.setColor(al(0xFFEFFBFF, 0.9f * ca));
        for (int k = 0; k < 20; k++) {
            float a = k * TWO_PI / 20f - spin;
            c.drawCircle((float) Math.cos(a) * 0.9f * big, (float) Math.sin(a) * 0.9f * big, 0.035f * big, fill);
        }
        for (int k = 0; k < 28; k++) {
            float a = k * TWO_PI / 28f + spin;
            float px = (float) Math.cos(a) * 0.75f * big, py = (float) Math.sin(a) * 0.75f * big;
            float q = 0.022f * big;
            if (k % 2 == 0) c.drawCircle(px, py, q, fill);
            else c.drawRect(px - q, py - q, px + q, py + q, fill);
        }

        // шестиконечная звезда
        line.setStrokeWidth(thin);
        line.setColor(al(0xFFEFFBFF, 0.9f * ca));
        for (int tri = 0; tri < 2; tri++) {
            path.reset();
            for (int k = 0; k < 3; k++) {
                float a = -spin * 1.5f + tri * TWO_PI / 6f + k * TWO_PI / 3f;
                float px = (float) Math.cos(a) * 0.62f * big, py = (float) Math.sin(a) * 0.62f * big;
                if (k == 0) path.moveTo(px, py);
                else path.lineTo(px, py);
            }
            path.close();
            c.drawPath(path, line);
        }

        // полумесяц в центре
        line.setStrokeWidth(0.07f * big);
        line.setColor(al(0xFFEFFBFF, 0.95f * ca));
        rect.set(-0.2f * big, -0.2f * big, 0.2f * big, 0.2f * big);
        c.drawArc(rect, 40f + spin * 20f, 280f, false, line);
        c.restore();
    }

    /** Цепи падают сверху к стему, а потом утягивают его вниз. */
    private void drawChains(Canvas c, Stem s, long now) {
        float t = now - s.stateT;
        if (t < CH_LIFT) return;
        float fade = 1f;
        if (t > CH_PULL) fade = 1f - clamp((t - CH_PULL) / (float) (CH_END - CH_PULL), 0f, 1f);
        if (fade <= 0f) return;
        float p = easeOut((t - CH_LIFT) / (float) (CH_DROP - CH_LIFT));
        float r = s.r;
        float sc = s.chainScale;
        for (int i = 0; i < 5; i++) {
            float o = i - 2;
            float ax = s.crossX + o * 1.1f * r;
            float ay = -30f * dp;
            float bx = s.x + o * 0.3f * r * sc;
            float by = s.y - 0.45f * r * sc + Math.abs(o) * 0.14f * r * sc;
            drawChain(c, ax, ay, ax + (bx - ax) * p, ay + (by - ay) * p, fade);
        }
    }

    private void drawChain(Canvas c, float ax, float ay, float bx, float by, float fade) {
        float dx = bx - ax, dy = by - ay;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        float link = 14f * dp;
        if (len < link) return;
        float ux = dx / len, uy = dy / len;
        float deg = (float) Math.atan2(dy, dx) * 57.29578f;
        int n = (int) (len / link);
        for (int k = 0; k < n; k++) {
            float px = ax + ux * (k + 0.5f) * link, py = ay + uy * (k + 0.5f) * link;
            float hw = link * 0.62f;
            float hh = (k % 2 == 0) ? link * 0.34f : link * 0.11f;
            c.save();
            c.translate(px, py);
            c.rotate(deg);
            rect.set(-hw, -hh, hw, hh);
            line.setStrokeWidth(5f * dp);
            line.setColor(al(0xFF7FD8FF, 0.28f * fade));
            c.drawOval(rect, line);
            line.setStrokeWidth(2f * dp);
            line.setColor(al(0xFFE9FAFF, 0.95f * fade));
            c.drawOval(rect, line);
            c.restore();
        }
    }

    private void drawEgg(Canvas c, Egg e) {
        c.save();
        c.translate(e.x, e.y);
        c.rotate(e.rot * 57.29578f);
        fill.setShader(null);
        fill.setColor(0xFFF6EDD9);
        rect.set(-7.5f * dp, -10f * dp, 7.5f * dp, 10f * dp);
        c.drawOval(rect, fill);
        fill.setColor(0xFFE3D2B0);
        rect.set(-1f * dp, -4f * dp, 7.5f * dp, 10f * dp);
        c.drawOval(rect, fill);
        fill.setColor(0xFFFFFFFF);
        rect.set(-5f * dp, -8f * dp, -1f * dp, -2f * dp);
        c.drawOval(rect, fill);
        line.setColor(0xFFB89F76);
        line.setStrokeWidth(1f * dp);
        rect.set(-7.5f * dp, -10f * dp, 7.5f * dp, 10f * dp);
        c.drawOval(rect, line);
        c.restore();
    }

    private void drawPart(Canvas c, Part p, long now) {
        long age = now - p.born;
        float left = p.life - age;
        int alpha = left < 400 ? (int) (255f * left / 400f) : 255;
        if (alpha < 0) alpha = 0;
        fill.setShader(null);
        fill.setColor((alpha << 24) | (p.color & 0x00FFFFFF));
        if (p.kind == 1 || p.kind == 3) {
            c.drawCircle(p.x, p.y, p.size, fill);
            return;
        }
        c.save();
        c.translate(p.x, p.y);
        c.rotate(p.rot * 57.29578f);
        path.reset();
        path.moveTo(-p.size, p.size * 0.6f);
        path.lineTo(p.size * 0.2f, -p.size);
        path.lineTo(p.size, p.size * 0.7f);
        path.close();
        c.drawPath(path, fill);
        c.restore();
    }

    private void drawBubble(Canvas c, Stem s) {
        text.setTextSize(13f * dp);
        text.setFakeBoldText(true);
        float tw = text.measureText(s.bubble);
        float w = tw + 18f * dp, h = 26f * dp;
        float left = clamp(s.x - w / 2f, 4f * dp, getWidth() - w - 4f * dp);
        float top = s.y - s.r * 1.35f - h - 6f * dp;
        if (top < 4f * dp) top = 4f * dp;
        fill.setShader(null);
        fill.setColor(0xF2FFFFFF);
        rect.set(left, top, left + w, top + h);
        c.drawRoundRect(rect, 12f * dp, 12f * dp, fill);
        path.reset();
        float px = clamp(s.x, left + 12f * dp, left + w - 12f * dp);
        path.moveTo(px - 5f * dp, top + h - 1f);
        path.lineTo(px, top + h + 6f * dp);
        path.lineTo(px + 5f * dp, top + h - 1f);
        path.close();
        c.drawPath(path, fill);
        text.setColor(0xFF22222A);
        c.drawText(s.bubble, left + w / 2f, top + h / 2f - (text.ascent() + text.descent()) / 2f, text);
        text.setFakeBoldText(false);
    }

    private void drawMenu(Canvas c) {
        fill.setShader(null);
        for (int i = 0; i < 3; i++) {
            RectF b = btn[i];
            int col;
            switch (btnAct[i]) {
                case A_SMASH: col = 0xFFE0453A; break;
                case A_CROSS: col = 0xFF8A5A2E; break;
                case A_FEED: col = 0xFFE59A12; break;
                default: col = 0xFF3E9A55; break;
            }
            if (pressedBtn == i) col = (col & 0xFF000000) | ((col & 0x00FEFEFE) >> 1);
            fill.setColor(col);
            c.drawRoundRect(b, 12f * dp, 12f * dp, fill);
            line.setColor(0xCCFFFFFF);
            line.setStrokeWidth(1.5f * dp);
            c.drawRoundRect(b, 12f * dp, 12f * dp, line);

            float size = 13f * dp;
            text.setFakeBoldText(true);
            text.setTextSize(size);
            float maxW = b.width() - 12f * dp;
            while (text.measureText(btnLabel[i]) > maxW && size > 8f * dp) {
                size -= 0.5f * dp;
                text.setTextSize(size);
            }
            text.setColor(0xFFFFFFFF);
            c.drawText(btnLabel[i], b.centerX(), b.centerY() - (text.ascent() + text.descent()) / 2f, text);
            text.setFakeBoldText(false);
        }
    }

    private void drawPop(Canvas c, Pop p, long now) {
        float t = (now - p.born) / 900f;
        if (t < 0f || t > 1f) return;
        int alpha = (int) (255f * (1f - t * t));
        text.setTextSize(20f * dp);
        text.setFakeBoldText(true);
        text.setColor((alpha << 24) | 0x00000000);
        c.drawText(p.text, p.x + 1.5f * dp, p.y - 50f * dp * t + 1.5f * dp, text);
        text.setColor((alpha << 24) | (p.color & 0x00FFFFFF));
        c.drawText(p.text, p.x, p.y - 50f * dp * t, text);
        text.setFakeBoldText(false);
    }

    private void safeLog(String s) {
        try {
            logger.log(s);
        } catch (Throwable ignored) {
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}

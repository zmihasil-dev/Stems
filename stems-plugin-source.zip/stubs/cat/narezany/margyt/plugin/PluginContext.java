package cat.narezany.margyt.plugin;
public interface PluginContext {
  android.content.Context context();
  void log(String s);
  android.content.SharedPreferences prefs();
}

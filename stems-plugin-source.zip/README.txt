Стемы — плагин для margyT (формат .mtp = zip: manifest.json + classes.dex + icon.png).
Исходники: src/stems/margyt/*.java. Сборка: ./build.sh (нужен Android SDK, см. шапку скрипта).
Управление: тап по стему — меню (Разбить / Распять / Кормить яйцами), тащить и отпустить — бросок.
